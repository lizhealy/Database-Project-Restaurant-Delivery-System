<html>
<link rel="stylesheet" href="mainstyle.css" type="text/css">
<body>

<center><h1> Your order has been sent </h><p>

<h3><a href="admin_home.php">Return to homepage</a></h3></center>

</body>
</html>