<html>
<link rel="stylesheet" href="mainstyle.css" type="text/css">
<body>

<center><h1> Your order has been placed </h><p>

<h3><a href="customer_home.php">Return to homepage</a></h3></center>

</body>
</html>