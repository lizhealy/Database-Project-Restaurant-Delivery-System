<ul>
<li><a href="admin_profile.php">Admin Profile</a></li>
<li><a href="admin_menus.php">Menus</a></li>
<li><a href="admin_drivers.php">Delivery Drivers</a></li>
<li><a href="admin_zones.php">Delivery Zones</a></li>
<li><a href="admin_rewards.php">Rewards</a></li>
</ul>