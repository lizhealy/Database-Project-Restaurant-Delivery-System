<body>
<?php

echo "<div id='welcome'><p><center><h1>Restaurant Database</h1><br><h3>Liz Healy<br>CSIS 601<br>Spring 2017<br>Final Project</h3></center></div>";

//include auth.php file on all secure pages
include("dbconnect.php");
?>
<!DOCTYPE html>
<html>
<link rel="stylesheet" href="mainstyle.css" type="text/css">
<head>
<meta charset="utf-8">
<title>Final Project</title>
</head>
<body>
<div class="form">
<center>
<p><a href="register.php">Click to Begin</a></p>
</center>
</div>
</body>
</html>